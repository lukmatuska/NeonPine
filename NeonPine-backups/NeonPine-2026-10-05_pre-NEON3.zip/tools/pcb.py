#!/usr/bin/env python3
"""Build NeonPine.kicad_pcb from the schematic netlist: outline, placement, zones.
Usage: python3 tools/pcb.py <netlist.net>   (routing is done afterwards with Freerouting)"""
import sys, math, json, os
import pcbnew
from sx import parse

HERE = os.path.dirname(os.path.abspath(__file__))
PRJ = os.path.join(HERE, '..')
PCB = os.path.join(PRJ, 'NeonPine.kicad_pcb')
FPL = '/usr/share/kicad/footprints/'
OX, OY = 100.0, 40.0          # board origin offset (mm); design coords: x right, y down, (0,0) = star tip
MM = pcbnew.FromMM

# ---------------- net classes (written to the project file before the board is created)
HV_PAT = ['/HV+', '/SW', 'Net-(LA*', 'Net-(Q??-C)', 'Net-(R5-Pad2)']
PWR_PAT = ['/VBUS', '+5V', 'GND']
def write_project():
    def cls(name, clr, tw, vd=0.6, vdr=0.3, prio=0):
        return dict(name=name, clearance=clr, track_width=tw, via_diameter=vd, via_drill=vdr,
                    microvia_diameter=0.3, microvia_drill=0.1, diff_pair_width=0.2, diff_pair_gap=0.25,
                    diff_pair_via_gap=0.25, wire_width=6, bus_width=12, line_style=0, priority=prio,
                    schematic_color='rgba(0, 0, 0, 0.000)', pcb_color='rgba(0, 0, 0, 0.000)')
    prj = {"meta": {"filename": "NeonPine.kicad_pro", "version": 3},
           "board": {"design_settings": {"rules": {"min_clearance": 0.15, "min_track_width": 0.15,
                     "min_via_diameter": 0.5, "min_through_hole_diameter": 0.3, "min_copper_edge_clearance": 0.3,
                     "min_hole_clearance": 0.25, "min_hole_to_hole": 0.25}}},
           "net_settings": {"meta": {"version": 4},
                            "classes": [cls('Default', 0.2, 0.25), cls('HV', 0.5, 0.3, 0.7, 0.35, 1),
                                        cls('PWR', 0.2, 0.5, 0.7, 0.35, 2)],
                            "netclass_patterns": [{"netclass": "HV", "pattern": p} for p in HV_PAT] +
                                                 [{"netclass": "PWR", "pattern": p} for p in PWR_PAT]}}
    json.dump(prj, open(os.path.join(PRJ, 'NeonPine.kicad_pro'), 'w'), indent=2)

# ---------------- outline: star + 3 tiers + pot
def P(x, y): return pcbnew.VECTOR2I(MM(OX + x), MM(OY + y))
def poly(pts):
    s = pcbnew.SHAPE_POLY_SET(); s.NewOutline()
    for x, y in pts: s.Append(MM(OX + x), MM(OY + y))
    return s
def outline():
    star = [(r * math.cos(math.radians(a)), 10.5 - r * math.sin(math.radians(a)))
            for k in range(10) for a, r in [(90 + 36 * k, 10.5 if k % 2 == 0 else 4.4)]]
    shapes = [star,
              [(0, 12), (14, 30), (-14, 30)],
              [(0, 22), (20, 44), (-20, 44)],
              [(0, 31), (30, 56), (-30, 56)],
              [(-21, 55.5), (21, 55.5), (21, 59.5), (18, 59.5), (18, 68.5), (16.5, 70), (-16.5, 70), (-18, 68.5), (-18, 59.5), (-21, 59.5)]]
    u = poly(shapes[0])
    for s in shapes[1:]: u.BooleanAdd(poly(s))
    u.Simplify()
    return u

# ---------------- fixed parts (design coords, rotation, side)
LAMPS = {2: (-4, 19.15), 3: (4, 19.15), 4: (-7, 31.65), 5: (0, 31.65), 6: (7, 31.65),
         7: (-13, 43.15), 8: (-4.5, 43.15), 9: (4.5, 43.15), 10: (13, 43.15)}   # anode (top) pad of each vertical lamp
FIXED = {
    'LA1': (-6.35, 8.6, 0, 'F'),               # star lamp lies across the star arms
    'R21': (3.25, 8.6, 0, 'B'), 'Q11': (-1.6, 10.2, 0, 'B'), 'R41': (-1.6, 13.3, 0, 'B'),
    'TP1': (0, 12.2, 0, 'F'),                 # star touch pad (front, under the star lamp)
    'TP2': (-12, 66.0, 0, 'F'),               # pot touch pad (front)
    'R8': (-21.2, 52.5, 0, 'F'),              # LDR = ornament in the left wing
    'J2': (2.54, 68.3, 270, 'F'),            # SWD pads 5V/SWIO/GND
    'J1': (18 - 3.4, 63.5, 270, 'B'),          # USB-C, mouth flush with the right pot edge
    'Q1': (-14, 62.5, 90, 'B'), 'L11': (-4.5, 62.6, 0, 'B'), 'U1': (5.6, 62.5, 90, 'B'),
    'D1': (-8.75, 50.5, 90, 'B'), 'C4': (0, 47.6, 0, 'B'), 'D2': (0, 52.85, 90, 'B'),
}
# every vertical lamp: R_L / R_B / Q stacked on the back in the strip between its two pads
for n, (x, ya) in LAMPS.items():
    FIXED[f'LA{n}'] = (x, ya + 12.7, 90, 'F')
    FIXED[f'R{20 + n}'] = (x, ya + 3.1, 90, 'B')
    FIXED[f'R{40 + n}'] = (x, ya + 6.1, 0, 'B')
    FIXED[f'Q{10 + n}'] = (x, ya + 12.7 - 3.5, 0, 'B')
# small parts, hand-placed in the free pockets (rim strips between lamp pads, wings, pot bottom)
FIXED.update({
    'C3': (0, 57.6, 0, 'B'), 'R1': (-7.0, 57.0, 90, 'B'), 'R2': (-9.6, 56.9, 90, 'B'),
    'R5': (9.5, 48.0, 90, 'B'), 'R6': (9.5, 51.5, 90, 'B'), 'R7': (7.2, 57.0, 90, 'B'), 'C6': (9.0, 57.0, 90, 'B'),
    'R11': (6.0, 67.7, 0, 'B'), 'C7': (-5.6, 67.9, 90, 'B'), 'TP3': (-8.5, 68.0, 0, 'B'),
    'C5': (-23, 55.0, 0, 'B'), 'R9': (-17.0, 48.4, 0, 'B'), 'R10': (-17.0, 50.2, 0, 'B'),
    'C1': (17.2, 56.8, 0, 'B'), 'C2': (17.2, 54.6, 0, 'B'),
    'R3': (17.2, 52.4, 0, 'B'), 'R4': (17.2, 50.2, 0, 'B'), 'F1': (21.2, 52.6, 0, 'B'),
})
ORDER = []
BIGNETS = {'GND', '+5V', '/HV+'}
GAP = 0.3   # extra spacing around each placed part (routing room)

def load_netlist(path):
    e = parse(open(path).read())[0]
    g = lambda l, k: next(x for x in l if isinstance(x, list) and x[0] == k)
    comps = {}
    for c in g(e, 'components')[1:]:
        ref = g(c, 'ref')[1].strip('"')
        ts = [x for x in c if isinstance(x, list) and x[0] == 'tstamps'][-1][1].strip('"')
        comps[ref] = dict(val=g(c, 'value')[1].strip('"'), fp=g(c, 'footprint')[1].strip('"'), ts=ts, pins={})
    for n in g(e, 'nets')[1:]:
        name = g(n, 'name')[1].strip('"')
        for nd in [x for x in n if isinstance(x, list) and x[0] == 'node']:
            comps[g(nd, 'ref')[1].strip('"')]['pins'][g(nd, 'pin')[1].strip('"')] = name
    return comps

def main(netfile):
    write_project()
    comps = load_netlist(netfile)
    board = pcbnew.NewBoard(PCB)
    ol = outline()
    # edge cuts
    o = ol.Outline(0)
    for i in range(o.PointCount()):
        a, b = o.CPoint(i), o.CPoint((i + 1) % o.PointCount())
        s = pcbnew.PCB_SHAPE(board); s.SetShape(pcbnew.SHAPE_T_SEGMENT); s.SetLayer(pcbnew.Edge_Cuts)
        s.SetStart(a); s.SetEnd(b); s.SetWidth(MM(0.1)); board.Add(s)
    inner = pcbnew.SHAPE_POLY_SET(ol); inner.Inflate(-MM(0.35), pcbnew.CORNER_STRATEGY_CHAMFER_ALL_CORNERS, MM(0.01))
    # nets
    nets = {}
    for c in comps.values():
        for n in c['pins'].values():
            if n not in nets:
                nets[n] = pcbnew.NETINFO_ITEM(board, n); board.Add(nets[n])
    fps = {}
    def make(ref):
        c = comps[ref]; lib, name = c['fp'].split(':')
        fp = pcbnew.FootprintLoad(FPL + lib + '.pretty', name)
        fp.SetFPID(pcbnew.LIB_ID(lib, name)); fp.SetReference(ref); fp.SetValue(c['val'])
        fp.SetPath(pcbnew.KIID_PATH('/' + c['ts']))
        fp.Reference().SetLayer(pcbnew.F_Fab)   # keep silkscreen for art only
        for pad in fp.Pads():
            if pad.GetNumber() in c['pins']: pad.SetNet(nets[c['pins'][pad.GetNumber()]])
        board.Add(fp); fps[ref] = fp
        return fp
    def put(fp, x, y, rot, side):
        if fp.IsFlipped(): fp.Flip(fp.GetPosition(), pcbnew.FLIP_DIRECTION_LEFT_RIGHT)
        fp.SetOrientationDegrees(0); fp.SetPosition(P(x, y)); fp.SetOrientationDegrees(rot)
        if side == 'B': fp.Flip(fp.GetPosition(), pcbnew.FLIP_DIRECTION_LEFT_RIGHT)
    def crt(fp):
        lay = pcbnew.B_CrtYd if fp.IsFlipped() else pcbnew.F_CrtYd
        c = fp.GetCourtyard(lay)
        bb = c.BBox() if c.OutlineCount() else fp.GetBoundingBox(False)
        return [bb.GetLeft() / 1e6 - OX, bb.GetTop() / 1e6 - OY, bb.GetRight() / 1e6 - OX, bb.GetBottom() / 1e6 - OY]
    rects = {'F': [], 'B': []}; keep = []   # keep: THT pad keepouts (both sides)
    for ref, (x, y, rot, side) in FIXED.items():
        fp = make(ref); put(fp, x, y, rot, side); rects[side].append(crt(fp))
        for pad in fp.Pads():
            if pad.HasHole():
                px, py = pad.GetPosition().x / 1e6 - OX, pad.GetPosition().y / 1e6 - OY
                r = max(pad.GetSize(pcbnew.F_Cu).x, pad.GetSize(pcbnew.F_Cu).y) / 2e6 + 0.6
                keep.append([px - r, py - r, px + r, py + r])
    hit = lambda a, b: a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]
    def inside(r):
        x0, y0, x1, y1 = r
        nx, ny = max(2, int((x1 - x0) / 0.5) + 1), max(2, int((y1 - y0) / 0.5) + 1)
        pts = [(x0 + (x1 - x0) * i / (nx - 1), y) for i in range(nx) for y in (y0, y1)] + \
              [(x, y0 + (y1 - y0) * j / (ny - 1)) for j in range(ny) for x in (x0, x1)]
        return all(inner.Contains(P(x, y)) for x, y in pts)
    offs = sorted(((dx * 0.25, dy * 0.25) for dx in range(-160, 161) for dy in range(-160, 161)),
                  key=lambda d: d[0] ** 2 + d[1] ** 2)
    def target(ref, fb):
        pts = []
        for pn, n in comps[ref]['pins'].items():
            if n in BIGNETS: continue
            for r2, f2 in fps.items():
                if r2 == ref: continue
                for pad in f2.Pads():
                    if pad.GetNetname() == n:
                        pts.append((pad.GetPosition().x / 1e6 - OX, pad.GetPosition().y / 1e6 - OY))
        if pts: return (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))
        return fb or (0, 50)
    for ref, fb in ORDER:
        fp = make(ref); tx, ty = target(ref, fb)
        shapes = []
        for rot in (0, 90):
            put(fp, 0, 0, rot, 'B'); r = crt(fp); shapes.append((rot, [r[0] - GAP, r[1] - GAP, r[2] + GAP, r[3] + GAP]))
        done = False
        for dx, dy in offs:
            for rot, (a, b, c, d) in shapes:
                r = [a + tx + dx, b + ty + dy, c + tx + dx, d + ty + dy]
                if inside(r) and not any(hit(r, q) for q in rects['B']) and not any(hit(r, q) for q in keep):
                    put(fp, tx + dx, ty + dy, rot, 'B'); rects['B'].append(r); done = True; break
            if done: break
        if not done: print('!! could not place', ref)
    # silkscreen art on the front
    def text(t, x, y, h, layer=pcbnew.F_SilkS):
        s = pcbnew.PCB_TEXT(board); s.SetText(t); s.SetPosition(P(x, y)); s.SetLayer(layer)
        s.SetTextSize(pcbnew.VECTOR2I(MM(h), MM(h))); s.SetTextThickness(MM(h * 0.15))
        s.SetMirrored(layer == pcbnew.B_SilkS); board.Add(s)
    text('NEON PINE', 0, 62.6, 1.8)
    text('5V IO GND', 0, 66.4, 0.8)
    text('! 100 V DC !', 18, 50.5, 0.9, pcbnew.B_SilkS)
    # GND pours both layers
    for lay in (pcbnew.F_Cu, pcbnew.B_Cu):
        z = pcbnew.ZONE(board); z.SetLayer(lay); z.SetNet(nets['GND'])
        z.Outline().AddOutline(ol.Outline(0)); z.SetLocalClearance(MM(0.3))
        z.SetMinThickness(MM(0.25)); z.SetThermalReliefGap(MM(0.3)); z.SetThermalReliefSpokeWidth(MM(0.4))
        z.SetAssignedPriority(0); board.Add(z)
    board.GetDesignSettings().SetBoardThickness(MM(1.6))
    pcbnew.SaveBoard(PCB, board)
    print('placed', len(fps), 'footprints')

if __name__ == '__main__':
    main(sys.argv[1])
