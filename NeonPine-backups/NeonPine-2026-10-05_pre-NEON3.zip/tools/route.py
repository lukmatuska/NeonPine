#!/usr/bin/env python3
"""Autoroute NeonPine.kicad_pcb with Freerouting, then refill zones.
Usage: python3 tools/route.py <freerouting.jar> [passes]"""
import sys, os, subprocess
import pcbnew

PRJ = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
PCB = os.path.join(PRJ, 'NeonPine.kicad_pcb')
jar, passes = sys.argv[1], (sys.argv[2] if len(sys.argv) > 2 else '40')
dsn, ses = PCB.replace('.kicad_pcb', '.dsn'), PCB.replace('.kicad_pcb', '.ses')

b = pcbnew.LoadBoard(PCB)
seq = lambda c: [c[i] for i in range(len(c))]   # SWIG iterators are broken on Python 3.14
for t in seq(b.Tracks()): b.Remove(t)
zones = seq(b.Zones())
for z in zones: b.Remove(z)                    # pours would be exported as blocking planes
assert pcbnew.ExportSpecctraDSN(b, dsn), 'DSN export failed'
subprocess.run(['java', '-jar', jar, '-de', dsn, '-do', ses, '-mp', passes, '--gui.enabled=false'], check=True)
assert pcbnew.ImportSpecctraSES(b, ses), 'SES import failed'
for z in zones: b.Add(z)
pcbnew.ZONE_FILLER(b).Fill(b.Zones())
pcbnew.SaveBoard(PCB, b)
for f in (dsn, ses): os.remove(f)
print('routed:', len(b.Tracks()), 'track items')
